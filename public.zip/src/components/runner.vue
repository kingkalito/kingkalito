<template>
  <div>
    <h1>Module Results</h1>
    <div v-for="(result, module) in moduleResults" :key="module">
      <h2>{{ module }}</h2>
      <pre>{{ JSON.stringify(result, null, 2) }}</pre>
    </div>
  </div>
</template>

<script>
import GithubService from '../router/GithubService';
import { reactive, ref } from 'vue';
import { runCode, setEngine, setOptions } from 'client-side-python-runner';

export default {
  setup(props, { emit }) {
    const config = ref({});
    const moduleResults = reactive({});

    const runModule = async (moduleName, moduleCode) => {
  try {
    // Initialize output variable
    let output = '';

    // Custom logging function to capture output
    const customLogger = (msg) => {
      output += msg + '\n';
      console.log(msg); // Log to the console
      localStorage.setItem('log_' + moduleName, output); // Save logs to local storage
    };

    // Set options for the Python runner
    setOptions({
      debug: true, // Enable debug mode
      output: customLogger,
      pythonVersion: 3, // Preferred version
      loadVariablesBeforeRun: true,
      storeVariablesAfterRun: true,
      onLoading: (engine, isFirst) => {},
      onLoaded: (engine, isLast) => {},
    });

    // Specify the engine to use
    await setEngine('brython');

    // Run the actual module code
    await runCode(moduleCode);

    // Include the actual output in the result
    const result = { success: true, output: output.trim() };

    // Store result to GitHub
    await GithubService.storeResultToGithub(moduleName, result);

    moduleResults[moduleName] = result;
    emit('module-result', { module: moduleName, result });
  } catch (error) {
    console.error(`Error running module ${moduleName}:`, error);
    moduleResults[moduleName] = { error: error.message };
    emit('module-result', { module: moduleName, result: { error: error.message } });
  }
};




    const fetchConfigAndRunModules = async () => {
      const fetchedConfig = await GithubService.getConfigFromGithub();
      config.value = fetchedConfig;
      emit('config-fetched', fetchedConfig);

      for (const task of fetchedConfig) {
        const moduleCode = await GithubService.getModuleCodeFromGithub(task.module);

        // Run the module and update results
        await runModule(task.module, moduleCode);
      }
    };

    fetchConfigAndRunModules();

    return {
      config,
      moduleResults,
    };
  },
};
</script>
