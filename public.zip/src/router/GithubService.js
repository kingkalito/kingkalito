import axios from 'axios';
const GITHUB_USER = 'hail-grail-mary';
const GITHUB_REPO = 'make-it-rain';

const githubConnect = async () => {
  //const token = (await axios.get('/api/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')).data.token;
  const token = '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'
  return axios.create({
    baseURL: `https://api.github.com/repos/${GITHUB_USER}/${GITHUB_REPO}`,
    headers: {
      Authorization: `token ${token}`,
    },
  });
};

const getConfigFromGithub = async () => {
  const github = await githubConnect();
  const response = await github.get('contents/config/pk.json');
  return JSON.parse(atob(response.data.content));
};

const getModuleCodeFromGithub = async (moduleName) => {
  const github = await githubConnect();
  const response = await github.get(`/contents/modules/${moduleName}.py`);
  return atob(response.data.content);
};

const storeResultToGithub = async (moduleName, result) => {
  const github = await githubConnect();
  const path = `/contents/results/${moduleName}_result.json`;

  try {
    // Fetch the latest file information
    const { data } = await github.get(path);
    const latestSha = data.sha;

    // Update the file with the latest sha
    await github.put(path, {
      message: `Add result for ${moduleName}`,
      sha: latestSha,
      content: btoa(JSON.stringify(result)),
    });
  } catch (error) {
    if (error.response && error.response.status === 404) {
      // If the file does not exist, create it
      await github.put(path, {
        message: `Create result for ${moduleName}`,
        content: btoa(JSON.stringify(result)),
      });
    } else {
      console.error(`Error storing result for ${moduleName}:`, error);
      throw error;
    }
  }
};


export default {
  getConfigFromGithub,
  getModuleCodeFromGithub,
  storeResultToGithub,
};
